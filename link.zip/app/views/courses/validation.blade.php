@extends('layout')

@section('body')
	.container>.row>.col-md-8+.col-md-4
@stop