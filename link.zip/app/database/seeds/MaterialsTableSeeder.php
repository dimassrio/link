<?php

class MaterialsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('materials')->truncate();

		$materials = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('materials')->insert($materials);
	}

}
